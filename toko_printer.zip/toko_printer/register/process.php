<?php 

// Sambungin ke database
require '../koneksi.php';

// deklariskan data data apa saja yang akan di masukin ke dalam register
$nama_lengkap = htmlspecialchars($_POST["nama_lengkap"]);
$username = htmlspecialchars($_POST["username"]);
$password = htmlspecialchars($_POST["password"]);
$roles = 'Customer';

// masukin data ke dalam database 
$query = mysqli_query($conn, "INSERT INTO user VALUES(NULL, '$nama_lengkap', '$username', '$password', '$roles')");


// Kalau Berhasil, arahin ke halaman, kalau gagal tetap dihalaman regsiter 

if($query){
    echo " 
        <script type='text/javascript'>
            alert('YAY ! register berhasil, silahkan login yaa !!!')
            window.location = '../login/index.php';
        </script>
    ";
}else{
    echo " 
        <script type='text/javascript'>
            alert('yaaa register gagal, silahkan diulang yaa !!!')
            window.location = 'index.php';
        </script>
    ";
}

?>