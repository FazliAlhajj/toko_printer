<?php 

session_start();
unset($_SESSION["username"]);
session_destroy();


echo " 
    <script type='text/javascript';
       alert('Yes! Anda berhasil logout');
       window.location = 'index.php';
    </script>
"

?>