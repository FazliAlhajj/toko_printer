<?php 
session_start();
if(!isset($_SESSION["username"])){
    echo " 
        <script type='text/javascript'>
            alert('Silahkan login terlebih dahulu')
            window.location = '../login/index.php';
        </script>
    ";
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Halo, Selamat Datang <?= $_SESSION["nama_lengkap"]; ?></h1>
    <a href="../logout.php" onclick="return confirm('Apakah anda yakin ingin logout?');">Logout</a>
</body>
</html>