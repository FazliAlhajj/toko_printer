<?php

require "koneksi.php";

$barang = mysqli_query($conn , "SELECT * FROM barang")

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-
    
    8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Data Barang</h1>
    <a href="tambahbarang.php" class="tambah">Tambah data</a>
    <table border="1" cellpadding="10" cellspacing="0">
        <tr>
            <th>Id Barang</th>
            <th>Kode Barang</th>
            <th>Nama Barang</th>
            <th>Stok</th>
            <th>Kondisi</th>
            <th>Aksi</th>
        </tr>

        <?php $i = 1 ; ?>
        <?php while($data = mysqli_fetch_array($barang)) : ?>
        <tr>
            <td><?= $i; ?></td>
            <td><?= $data["kode_barang"]; ?></td>
            <td><?= $data["nama"]; ?></td>
            <td><?= $data["stok"] ; ?></td>
            <td><?= $data["kondisi"]; ?></td>
            <td>
                <a href="hapusbarang.php?id=<?= $data["id_barang"]; ?>" onclick="return confirm('anda yakin ingin menghapus data ini ?')">Hapus</a>
                <a href="editbarang.php?id=<?= $data["id_barang"]; ?>">Edit</a>
            </td>
        </tr>
        <?php $i++ ; ?>
        <?php endwhile; ?>
    </table>
</body>
</html>