<?php

require 'koneksi.php';

$id = $_POST["id_barang"];
$kode_barang = $_POST["kode_barang"];
$nama = $_POST["nama"];
$stok = $_POST["stok"];
$kondisi = $_POST["kondisi"];

$query = mysqli_query($conn, "UPDATE barang SET 
kode_barang = '$kode_barang',
nama = '$nama',
stok = '$stok',
kondisi = '$kondisi' WHERE id_barang = '$id' ");

if($query){
    echo'
        <script type="text/javascript">
            alert("data berhasil diubah!");
            window.location = "index.php";
        </script>  
    ';
}

?>