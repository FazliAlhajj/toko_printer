<?php

require 'koneksi.php';

$kode_barang = $_POST["kode_barang"];
$nama = $_POST["nama"];
$stok = $_POST["stok"];
$kondisi = $_POST["kondisi"];


$query = mysqli_query($conn ,"INSERT INTO barang VALUES(NULL, '$kode_barang', '$nama','$stok','$kondisi')");

if($query){
    echo'
        <script type="text/javascript">
            alert("data berhasil ditambahkan!");
            window.location = "index.php";
        </script>  
    ';
}else{
    echo'
    <script type="text/javascript">
        alert("data gagal ditambahkan!");
        window.location = "tambahbarang.php";
    </script>  
    ';
}













?>