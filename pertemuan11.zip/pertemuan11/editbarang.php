<?php

require "koneksi.php";

$id = $_GET["id"];
$barang = mysqli_query($conn, "SELECT * FROM barang WHERE id_barang = '$id'");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>edit - barang</title>
</head>
<body>
    <form action="updatebarang.php" method="POST">
    <h1>Edit Barang</h1>
        <?php while($data = mysqli_fetch_array($barang)) : ?>
            <input type="hidden" name="id_barang" class="form-control" value="<?= $data["id_barang"]; ?>"><br><br>
            
            <label name="kode_barang">Kode Barang</label> <br>
            <input type="int" name="kode_barang" class="form-control" value="<?= $data["kode_barang"]; ?>"><br><br>

            <label name="nama">Nama Barang</label> <br>
            <input type="text" name="nama" class="form-control" value="<?= $data["nama"] ; ?>"><br><br>

            <label name="stok">Stok</label> <br>
            <input type="text" name="stok" class="form-control" value="<?= $data["stok"] ; ?>"><br><br>

            <label name="kondisi">Kondisi</label>
            <select class="form-select" aria-label="Default select example" name="kondisi">
                <option selected>Silahkan Pilih Kondisi</option>
                <option value="layak">Layak</option>
                <option value="rusak">Rusak</option>
            </select>
           
            <button type="submit">Edit</button>
        <?php endwhile ; ?>
    </form>
</body>
</html>