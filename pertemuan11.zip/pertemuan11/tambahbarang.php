<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Olah data </title>
</head>
<body>
    <h1>Olah data Barang</h1>
    <div class="form-tambah">
        <form action="simpanbarang.php" method="post">
            <label for="kode_barang">Kode Barang</label> <br>
            <input type="number" name="kode_barang" id="kode_barang"> <br><br>   

            <label for="nama">Nama Barang</label><br>
            <input type="text" name="nama" id="nama"><br><br>
          

            <label for="stok">Stok</label><br>
            <input type="number" name="stok" id="stok"><br><br>
            

            <label for="kondisi" name="kondisi">Kondisi</label><br>
            <select class="form-select" aria-label="Default select example" name="kondisi">
                <option selected>Silahkan Pilih Kondisi</option>
                <option value="layak">Layak</option>
                <option value="rusak">Rusak</option>
            </select>

            <button type="submit" name="kirim">Tambah</button>

        </form>
    </div>
    
</body>
</html>
