<?php

require 'koneksi.php';

$id = $_GET["id"];

$query = mysqli_query($conn, "DELETE FROM barang WHERE id_barang = '$id'");

if($query){
    echo'
        <script type="text/javascript">
            alert("data berhasil dihapus!");
            window.location = "index.php";
        </script>  
    ';
}else{
    echo'
    <script type="text/javascript">
        alert("data gagal dihapus!");
        window.location = "tambahbarang.php";
    </script>  
    ';
}




?>