<?php


$conn = mysqli_connect("localhost", "root" , "", "latihan_lsp");

function query($query){
    global $conn;

    $data = mysqli_query($conn, $query);
    $rows = [];

    while($row = mysqli_fetch_assoc($data)){
        $rows[] = $row;
    }

    return $rows;
}

function editBarang($data){
    global $conn;

    $id = htmlspecialchars($data["id"]);
    $kode_barang = htmlspecialchars($data["kode_barang"]);
    $nama = htmlspecialchars($data["nama"]);
    $stok = htmlspecialchars($data["stok"]);
    $kondisi = htmlspecialchars($data["kondisi"]);

    $query = "UPDATE barang SET
    kode_barang = '$kode_barang',
    nama = '$nama',
    stok = '$stok',
    kondisi = '$kondisi' where id_barang = '$id'";

    mysqli_query($conn, $query);
    return mysqli_affected_rows($conn);
}

function hapusBarang($id){
    global $conn;
    mysqli_query($conn, "DELETE FROM barang WHERE id_barang = '$id' ");

    return mysqli_affected_rows($conn);
}

?>